
const baseUrl = "https://api.vortexvantures.com/api/admin/";

export default baseUrl;