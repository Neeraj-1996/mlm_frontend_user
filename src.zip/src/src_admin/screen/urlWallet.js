const baseWallet = "https://api.vortexvantures.com/api/wallet/";

export default baseWallet;