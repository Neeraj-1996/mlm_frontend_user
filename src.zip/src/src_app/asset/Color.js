export const Colors = {

    background: '#EC8E22',
    backgroundBlue: '#1B334D',
    backgroundHeader: '#1D83D5',
    textColor: '#000',
    
   
  };
  