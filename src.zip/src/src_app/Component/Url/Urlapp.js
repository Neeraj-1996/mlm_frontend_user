
const baseUrlapp = 'https://api.vortexvantures.com/api/users/';

export default baseUrlapp;
