const grabUrlapp = 'https://api.vortexvantures.com/api/grab/';

export default grabUrlapp;
