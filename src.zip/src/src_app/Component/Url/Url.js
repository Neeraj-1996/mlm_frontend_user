
const baseUrl = "https://www.smarttrade.org.in/public/api/v1/";
const baseUrlAdmin = "https://api.vortexvantures.com/api/admin/";

export default baseUrlAdmin;
